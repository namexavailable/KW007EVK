# Keywave KW007 ESPHome for ESP32-C3 v1.4

ESPHome / Home Assistant integration for the Keywave KW007-SE 5.8 GHz Doppler radar motion sensor.

This package is intended for normal use, evaluation, and further development by creators and product developers.

It provides live KW007 motion information, direction information, RSSI diagnostics, and user-adjustable range and GPO delay controls in Home Assistant.

---

## 1. What this package provides

Home Assistant sensors:

- **KW007 Motion**
- **KW007 Approaching**
- **KW007 Leaving**
- **KW007 Direction**
- **KW007 RSSI**

Home Assistant controls:

- **KW007 Detection Range**
- **KW007 GPO Delay**
- **KW007 Detection Update Rate**

The main purpose is to let users quickly evaluate:

- sensor response
- approaching / leaving detection
- range adjustment
- stable operation
- Home Assistant automation use

---

## 2. Required hardware

| Item | Purpose |
|---|---|
| KW007-SE | 5.8 GHz Doppler radar sensor |
| ESP32-C3 development board | I2C host and Wi-Fi connection |
| USB cable | Programming and power |
| Jumper wires | Sensor connection |
| Optional I2C pull-ups | Typical 4.7 kOhm if required by the board |
| Home Assistant | Dashboard and automation |
| ESPHome | Firmware build and Home Assistant integration |

---

## 3. Default wiring (ex. ESP32-C3 Mini is pin8 and 9)

This configuration defaults to:

```yaml
sda_pin: GPIO8
scl_pin: GPIO9
```

Typical connection:

| ESP32-C3 | KW007 |
|---|---|
| GPIO8 | SDA |
| GPIO9 | SCL |
| GND | GND |
| 3.3 V | KW007 3.3 V input |

Also connect:

```text
KW007 Range1
     |
    GND
```

For I2C / software-control mode, **Range1 must be connected directly to GND before power-up**.

Do not use a series resistor on Range1 in software-control mode. A resistor is used for hardware range selection; direct GND selects I2C control.

### Important

ESP32-C3 boards do not all use the same GPIO layout.

Check the pinout for the exact ESP32-C3 board being used. If necessary, change:

```yaml
substitutions:
  sda_pin: GPIO8
  scl_pin: GPIO9
```

---

## 4. Power

Use either the KW007 3.3 V input or 5 V input, never both.

3.3 V is recommended.

Never apply 5 V to the 3.3 V input.

---

## 5. Files in this package

```text
KW007_ESPHome_ESP32C3_v1.4/
|
|-- kw007_c3_homeassistant.yaml
|-- secrets.example.yaml
|-- README.md
|-- CHANGELOG.md
`-- LICENSE
```

For normal use, users only need to edit:

```text
secrets.yaml
kw007_c3_homeassistant.yaml
```

---

## 6. ESPHome setup

Install ESPHome using the preferred method for your environment.

if * Windows with Python:

```bat
python -m venv esphome-env
esphome-env\Scripts\activate
python -m pip install --upgrade pip
python -m pip install esphome
```

Using a virtual environment is recommended so ESPHome dependencies remain separate from other Python applications.

---

## 7. Create secrets.yaml

Copy:

```text
secrets.example.yaml
```

and rename the copy to:

```text
secrets.yaml
```

Then enter your Wi-Fi details:

```yaml
wifi_ssid: "YOUR_WIFI_NAME"
wifi_password: "YOUR_WIFI_PASSWORD"
fallback_password: "kw007setup"
```

Do not publish or share `secrets.yaml`.

---

## 8. Compile and install

Connect the ESP32-C3 by USB.

Compile and install:

```bat
python -m esphome run kw007_c3_homeassistant.yaml --device COM5
```
Replace `COM5` with the correct Windows COM port.

OR

```bat
python -m esphome run kw007_c3_homeassistant.yaml
```
It may found and ask your COM port or OTA method;


After the first successful installation, OTA updates may also be used if the ESP32-C3 is reachable over Wi-Fi.

---

## 9. Confirm successful startup

In the ESPHome log, look for:

```text
KW007 initialized. VCO bank=...
```

The KW007 I2C address is:

```text
0x19
```

If the device is not found, check:

- SDA / SCL pins
- GND
- power
- Range1 connection
- I2C pull-ups if required
- correct ESP32-C3 GPIO configuration

---

## 10. Home Assistant connection

In Home Assistant:

```text
Settings
-> Devices & services
-> Add Integration
-> ESPHome
```

Enter the ESP32-C3 IP address and keep the default native API port:

```text
6053
```

After connection, the KW007 device should appear automatically.

---

## 11. Home Assistant sensors

### KW007 Motion

Generic motion state.

It is active when either Approaching or Leaving is active.

### KW007 Approaching

Binary sensor intended for automations.

Use this when an action should happen as a person or object moves toward the sensor.

### KW007 Leaving

Binary sensor intended for automations.

Use this when an action should happen as a person or object moves away from the sensor.

### KW007 Direction

Human-readable status:

```text
Approaching
Leaving
Both
None
```

### KW007 RSSI

Reflected signal strength from:

```text
0 to 255
```

RSSI is useful for setup, evaluation and tuning.

It is not a distance measurement.

---

## 12. Home Assistant controls

### Detection Range

Available presets:

| Level | Approximate range |
|---:|---:|
| 1 | ~20 cm |
| 2 | ~50 cm |
| 3 | ~1 m |
| 4 | ~3 m |
| 5 | ~5 m |
| 6 | ~7 m |
| 7 | ~10 m |
| 8 | ~12 m, enhanced mode |

Recommended starting point:

```text
Level 4 (~3 m)
```

Each preset applies the corresponding gain, threshold, sensitivity and enhanced-mode settings automatically.

For stable evaluation, change one parameter at a time.

### Detection Range preset details

The range control follows the KW007 SDK v1.3 presets:

| Level | Amp1 | Amp2 | Amp3 | Threshold | Sensitivity | Enhanced |
|---:|---:|---:|---:|---:|---:|:---:|
| 1 | 4 | 0 | 0 | 80 | 2 | Off |
| 2 | 6 | 0 | 0 | 80 | 2 | Off |
| 3 | 4 | 5 | 0 | 80 | 2 | Off |
| 4 | 7 | 4 | 0 | 80 | 4 | Off |
| 5 | 7 | 7 | 0 | 90 | 8 | Off |
| 6 | 7 | 7 | 1 | 64 | 8 | Off |
| 7 | 7 | 7 | 3 | 32 | 8 | Off |
| 8 | 7 | 7 | 3 | 32 | 8 | On |

Levels 1-3 reproduce the sensor's hardware range-selection behaviour. Levels 4-8 are software-control presets provided by the SDK for extended tuning.

Sensitivity is part of the range preset and is applied automatically. Lower sensitivity values are more sensitive; higher values are less sensitive.


### GPO Delay

Available KW007-SE settings:

```text
1 second
16 seconds
32 seconds
64 seconds
```

This controls how long the KW007 hardware GPO remains active after motion stops.

### Detection Update Rate

Available host polling settings:

```text
Fast (50 ms)
Normal (125 ms)
Low Traffic (250 ms)
```

Recommended starting point:

```text
Normal (125 ms)
```

This setting controls how often ESPHome reads the KW007 status register.

It does **not** change the KW007 internal processing rate.

The KW007 Approach / Leaving flags update at approximately 8 Hz.

`Fast (50 ms)` can reduce host-side latency when reading a newly updated flag, but it does not make the KW007 itself operate at 20 Hz.

---

## 13. Recommended starting configuration

For first use:

```text
Detection Range:        Level 4 (~3 m)
GPO Delay:              1 second
Detection Update Rate:  Normal (125 ms)
I2C speed:              100 kHz
Supply:                 3.3 V recommended
Range1:                 Directly to GND
```

Start with these settings and change one parameter at a time.

---

## 14. Using KW007 for Home Assistant automations

The dedicated binary sensors make automations straightforward.

Typical logic:

```text
KW007 Approaching -> turn light ON
KW007 Leaving     -> wait -> turn light OFF
```

For automation triggers, use:

```text
KW007 Approaching
KW007 Leaving
KW007 Motion
```

`KW007 Direction` is mainly intended as a readable status display.

---

## 15. RSSI reporting and Home Assistant Activity

RSSI is intentionally retained because it is useful for evaluation and tuning.

However, frequent RSSI changes can make the Home Assistant Activity / Logbook difficult to read.

To keep RSSI available while preventing it from filling Activity, exclude only the RSSI entity from Logbook.

### Find the RSSI entity ID

In Home Assistant:

```text
Settings
-> Developer Tools
-> States
```

Search for:

```text
KW007 RSSI
```

The entity ID may look similar to:

```text
sensor.kw007_c3_kw007_rssi
```

### Exclude RSSI from Activity / Logbook

Add this to Home Assistant `configuration.yaml`:

```yaml
logbook:
  exclude:
    entities:
      - sensor.kw007_c3_kw007_rssi
```

Replace the entity ID with the actual ID used by your Home Assistant installation.

Then restart Home Assistant.

This keeps:

- RSSI visible on the device page
- RSSI available for dashboards and automations
- RSSI history available

but removes RSSI changes from the Activity / Logbook view.

If `configuration.yaml` already contains a `logbook:` section, add the RSSI entity to the existing section instead of creating a second `logbook:` section.

---

## 16. Motion vs stationary presence

KW007 Motion in this configuration is based on:

```text
Approaching OR Leaving
```

It is a motion indication.

It should not be treated as a dedicated stationary-presence or continuous occupancy flag.

---

## 17. RSSI update interval

RSSI is currently read every:

```text
5 seconds
```

This is intentionally slower than motion polling because RSSI is diagnostic information rather than a motion trigger.

Creators can modify this interval in the YAML if their application requires faster or slower diagnostic reporting.

---

## 18. I2C configuration

KW007 supports:

```text
100 kHz
400 kHz
```

This configuration uses:

```text
100 kHz
```

as a conservative default for stable operation.

Creators may change this to 400 kHz after validating their own hardware layout and wiring.

---

## 19. Further development

This configuration can be used directly or adapted for other applications.

Creators may modify it to:

- use different ESP32-C3 GPIO pins
- change motion polling interval
- change RSSI reporting interval
- use different detection-range presets
- create lighting automations
- wake displays on approach
- trigger alarms or appliances
- use Approaching / Leaving independently
- add custom Home Assistant dashboard controls
- integrate the KW007 logic into another ESPHome device

The KW007 register interface remains available for advanced development.

---

## 20. License

Copyright 2026 Keywave Technology.

SPDX-License-Identifier: Apache-2.0

Licensed under the Apache License, Version 2.0.

See `LICENSE` for the complete license text.
