# Changelog

## v1.3

- Added dedicated `KW007 Approaching` binary sensor.
- Added dedicated `KW007 Leaving` binary sensor.
- Added selectable Detection Update Rate:
  - Fast (50 ms)
  - Normal (125 ms)
  - Low Traffic (250 ms)
- RSSI reporting changed to 5 seconds.
- RSSI marked as diagnostic.
- Detection Range and GPO Delay remain user-adjustable.
- Default I2C speed remains 100 kHz for stable operation.
- README expanded for creator and customer use.
- Added Home Assistant Logbook guidance for excluding RSSI Activity entries.
