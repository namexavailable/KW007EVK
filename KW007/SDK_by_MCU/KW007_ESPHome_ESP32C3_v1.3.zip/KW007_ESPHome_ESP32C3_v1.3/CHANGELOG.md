# Changelog

## v1.4

- Updated ESPHome Detection Range presets to match KW007 SDK v1.3.
- Added range-preset sensitivity control via R10.
- Updated Level 1 range from ~15 cm to ~20 cm.
- Updated Level 8 range from ~13 m to ~12 m.
- Updated default Level 4 threshold from 90 to 80 and sensitivity to 4.
- Updated Range1 wiring guidance: connect directly to GND for I2C/software-control mode; no series resistor.
- Home Assistant sensors, GPO Delay, Detection Update Rate, RSSI diagnostics and automation entities remain unchanged.


## v1.3

- Added dedicated `KW007 Approaching` binary sensor.
- Added dedicated `KW007 Leaving` binary sensor.
- Added selectable Detection Update Rate:
  - Fast (50 ms)
  - Normal (125 ms)
  - Low Traffic (250 ms)
- RSSI reporting changed to 5 seconds.
- RSSI marked as diagnostic.
- Detection Range and GPO Delay remain user-adjustable.
- Default I2C speed remains 100 kHz for stable operation.
- README expanded for creator and customer use.
- Added Home Assistant Logbook guidance for excluding RSSI Activity entries.
