============================================================
 KW007 SDK v1.3 — Technical Documentation
 Keywave KW007 5.8 GHz Doppler Radar Sensor
 Release Date: 2026-09-07
============================================================

CONTENTS
--------
  KW007_SDK_v1.3.html     Complete API reference and integration
                          guide in a single file. Everything is
                          embedded — no images, scripts or style
                          sheets to go missing — so it opens from
                          an email attachment, a share or a USB
                          stick, on any operating system, with
                          nothing to unblock first. Send this one.

  html\                   The same content as a browsable site,
                          with a navigation tree and a search box.
                          Better to read, but it is a folder of
                          many files, so it has to be zipped to
                          go anywhere. Open html\index.html.

  KW007_Programming_Guide_v2.1.pdf
                          Register-level reference for the KW007
                          sensor — register map, settings tables,
                          and hardware notes.

  KW007SE Module Datasheet_v2.6.pdf
                          Module datasheet: pinout, the resistor
                          table for hardware range selection, and
                          electrical characteristics.

  RELEASE_NOTES_v1.3.txt  What changed in this release, and what
                          to re-check when upgrading.


NO MORE .CHM
------------
  Releases up to v1.2 shipped a compiled help file. It has been
  dropped.

  Windows marks any CHM that arrives by email, cloud storage, USB
  or a network share as untrusted, and then shows an empty content
  pane rather than an error. Every recipient had to find the file,
  open Properties and tick Unblock before they could read a word
  of it — and plenty of corporate policies disable CHM outright, so
  even that did not always work.

  KW007_SDK_v1.3.html carries the same content with none of that.


REBUILDING THE DOCUMENTATION
----------------------------
  Both formats are generated from the SDK sources and mainpage.md,
  so neither is kept under version control. From the repository
  root:

        doxygen Doxyfile                 -> Docs\html\
        python Docs\make_single_html.py  -> Docs\KW007_SDK_v1.3.html

  The single-file build needs pandoc on PATH. It takes the version
  number from KW007_SDK_VERSION_STRING, so the file name follows
  the SDK automatically.


SUPPORT
-------
For technical inquiries regarding the KW007 sensor or SDK,
please contact your Keywave representative.

============================================================

LICENSING
---------
  Copyright 2026 Keywave Technology.
  The first-party documentation, including this README, the programming
  guide PDF, generated HTML reference, and release notes, is licensed
  under the Apache License, Version 2.0 (SPDX: Apache-2.0). See ../LICENSE.
