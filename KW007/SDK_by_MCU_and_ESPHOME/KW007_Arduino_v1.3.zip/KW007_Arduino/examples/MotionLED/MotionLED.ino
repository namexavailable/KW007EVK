/**
 * ============================================================
 *  MotionLED.ino — Motion-Triggered LED Arduino Example
 *  Keywave KW007 5.8GHz Doppler Radar Sensor
 *  KW007_SDK_v1.2
 *  Released: 2026-08-24
 *
 *  Copyright 2026 Keywave Technology
 *  SPDX-License-Identifier: Apache-2.0
 *  Licensed under the Apache License, Version 2.0; see LICENSE.
 * ============================================================
 */

#include <Wire.h>
#include <KW007.h>

static bool lastApproaching = false;
static bool lastLeaving = false;

void blinkLED(uint8_t times)
{
    for (uint8_t i = 0; i < times; i++) {
        digitalWrite(LED_BUILTIN, HIGH);
        delay(150);
        digitalWrite(LED_BUILTIN, LOW);
        delay(150);
    }
}

void setup()
{
    pinMode(LED_BUILTIN, OUTPUT);
    digitalWrite(LED_BUILTIN, LOW);

    Serial.begin(115200);

    // Arduino Uno:
    // SDA = A4
    // SCL = A5
    Wire.begin();
    KW007_SetGPO_DelayDuration(DELAY_SETTING3);
    Serial.println("KW007 Motion LED Example");

    uint8_t status = KW007_Init();

    if (status != KW007_OK) {
        Serial.print("KW007 init failed. Error: 0x");
        Serial.println(status, HEX);

        // Fast continuous blink = initialization error
        while (1) {
            digitalWrite(LED_BUILTIN, HIGH);
            delay(100);
            digitalWrite(LED_BUILTIN, LOW);
            delay(100);
        }
    }

    // Range 4 = approximately 3 m
    status = KW007_SetDetectionRange(4);

    if (status != KW007_OK) {
        Serial.print("Set range failed. Error: 0x");
        Serial.println(status, HEX);
    }

    Serial.println("KW007 ready.");
}

void loop()
{
    KW007_Data data = KW007_Read();
    

    if (!data.ok) {
        Serial.println("KW007 read error");
        delay(128);
        return;
    }

    // Approaching event = blink twice
    // Only trigger when the flag changes from false -> true
    if (data.approaching && !lastApproaching) {
        Serial.println("Approaching");
        blinkLED(2);
    }

    // Leaving event = blink once
    // Only trigger when the flag changes from false -> true
    if (data.leaving && !lastLeaving) {
        Serial.println("Leaving");
        blinkLED(1);
    }

    lastApproaching = data.approaching;
    lastLeaving = data.leaving;

    delay(128);
}
