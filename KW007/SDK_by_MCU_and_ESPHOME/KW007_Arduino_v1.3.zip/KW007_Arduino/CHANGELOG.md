# Changelog

## v1.3.0 - 2026-09-07

- Updated `KW007_SetDetectionRange()` presets.
- Added sensitivity to all detection-range presets.
- Added `KW007_SetSensitivity(uint8_t level)`.
- Added `REG_SENSITIVITY` / R10 definitions and masks.
- Updated Range 1 to approximately 20 cm.
- Updated Range 8 to approximately 12 m.
- Clarified that Range1 must be connected directly to GND before power-up for I2C / software-control mode.
- Added R31 safety note; initialization writes R00-R30 only.
- Preserved the Arduino/ESP32 HAL improvements from the previous package.
- Updated package metadata and documentation for SDK v1.3.


## 1.2.0 Arduino package

- Packaged the KW007 v1.2 core driver as an installable Arduino library.
- Added `KW007.h` as the Arduino-friendly public include.
- Added Arduino IDE examples: `BasicRead` and `MotionLED`.
- Added Arduino Library Manager metadata (`library.properties`) and keywords.
- Preserved Apache-2.0 license headers on supplied Keywave source files.
- Corrected the malformed `KW007_SDK_VERSION` macro line in `KW007_api.h` so the header compiles.
- Added an explicit `Arduino.h` include in the Arduino HAL.
- Arduino HAL now maps Wire address-NACK status to `KW007_ERR_NO_DEVICE`, consistent with the public API documentation.
