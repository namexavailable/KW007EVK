"""
============================================================
 kw007.py — Python Driver for Raspberry Pi / Linux
 Keywave KW007 5.8GHz Doppler Radar Sensor
 KW007 Python SDK v1.3.0
 Released: 2026-09-07

 Copyright 2026 Keywave Technology
 SPDX-License-Identifier: Apache-2.0
 Licensed under the Apache License, Version 2.0; see LICENSE.

 Designed for Raspberry Pi 4 / 5 and other Linux systems
 using /dev/i2c-* through smbus2.
============================================================
"""

from dataclasses import dataclass
from typing import Optional

from smbus2 import SMBus, i2c_msg


KW007_I2C_ADDRESS = 0x19
KW007_REG_COUNT = 31

KW007_OK = 0x00
KW007_ERR_I2C = 0x10
KW007_ERR_NO_DEVICE = 0x20
KW007_ERR_PARAM = 0x30
KW007_ERR_VERIFY = 0x40

REG_VCO_FUSE = 0x01
REG_RSSI = 0x05
REG_FLAGS = 0x06
REG_MANUAL_MODE = 0x09
REG_SENSITIVITY = 0x0A
REG_VCO_CTRL = 0x0C
REG_AMP1_GAIN = 0x13
REG_AMP2_AMP3_GAIN = 0x14
REG_SLOW_SPEED = 0x15
REG_ENHANCED_MODE = 0x18
REG_THRESHOLD = 0x1B
REG_GPO_DELAY = 0x1D

FLAG_DAY_NIGHT = 1 << 3
FLAG_APPROACHING = 1 << 2
FLAG_LEAVING = 1 << 1

MASK_EFUSE_MODE = 0x20
MASK_SENSITIVITY = 0x0F
MASK_SENSITIVITY_RSVD = 0x30
MASK_SAMPLE_RATE = 0x80
MASK_RESERVED_R12 = 0x40
MASK_VCO_BANK = 0x3F
MASK_AMP1 = 0xE0
MASK_AMP2 = 0x07
MASK_AMP3 = 0x18
MASK_SLOW_DET = 0x20
MASK_ENHANCED = 0x40
MASK_FAST_SPEED_DET = 0x01
MASK_GPO_DELAY = 0x06

DEFAULT_REGS = [
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0xFC, 0x30, 0x88, 0x03, 0x54, 0x4B, 0x68, 0x55,
    0x98, 0xA0, 0x00, 0xEA, 0xF7, 0x5F, 0x02, 0x30,
    0xA0, 0x20, 0x9A, 0x30, 0x55, 0x75, 0x42,
]

_RANGE_PRESETS = {
    1: (4, 0, 0, 80, 2, False),
    2: (6, 0, 0, 80, 2, False),
    3: (4, 5, 0, 80, 2, False),
    4: (7, 4, 0, 80, 4, False),
    5: (7, 7, 0, 90, 8, False),
    6: (7, 7, 1, 64, 8, False),
    7: (7, 7, 3, 32, 8, False),
    8: (7, 7, 3, 32, 8, True),
}

# KW007-SE GPO hold-time mapping from Reg29[2:1]:
# 00=16s, 01=32s, 10=1s, 11=64s
_GPO_DELAY_SECONDS_TO_SETTING = {
    16: 0,
    32: 1,
    1: 2,
    64: 3,
}


@dataclass
class KW007Data:
    ok: bool
    approaching: bool = False
    leaving: bool = False
    is_day: bool = False
    rssi: int = 0

    @property
    def motion(self) -> bool:
        """True when either approaching or leaving motion is detected."""
        return self.approaching or self.leaving


class KW007Error(RuntimeError):
    """Base exception for KW007 driver errors."""


class KW007NoDeviceError(KW007Error):
    """Raised when the KW007 does not acknowledge on I2C."""


class KW007:
    """
    KW007 Python driver for Raspberry Pi / Linux.

    Parameters
    ----------
    bus:
        Linux I2C bus number. Raspberry Pi normally uses bus 1.
    address:
        7-bit I2C address. KW007 default/fixed address is 0x19.
    auto_open:
        Open the I2C bus immediately when True.
    """

    def __init__(
        self,
        bus: int = 1,
        address: int = KW007_I2C_ADDRESS,
        auto_open: bool = True,
    ):
        self.bus_number = bus
        self.address = address
        self._bus: Optional[SMBus] = None

        if auto_open:
            self.open()

    def open(self) -> None:
        if self._bus is None:
            self._bus = SMBus(self.bus_number)

    def close(self) -> None:
        if self._bus is not None:
            self._bus.close()
            self._bus = None

    def __enter__(self):
        self.open()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def _require_bus(self) -> SMBus:
        if self._bus is None:
            raise KW007Error("I2C bus is not open")
        return self._bus

    def write_reg(self, reg: int, value: int) -> None:
        if not (0 <= reg <= 0xFF and 0 <= value <= 0xFF):
            raise ValueError("Register and value must be 0..255")

        bus = self._require_bus()
        try:
            msg = i2c_msg.write(self.address, [reg, value])
            bus.i2c_rdwr(msg)
        except OSError as exc:
            if getattr(exc, "errno", None) in (5, 6, 121):
                raise KW007NoDeviceError(
                    f"KW007 did not respond at I2C address 0x{self.address:02X}"
                ) from exc
            raise KW007Error(f"I2C write failed: {exc}") from exc

    def read_reg(self, reg: int) -> int:
        if not 0 <= reg <= 0xFF:
            raise ValueError("Register must be 0..255")

        bus = self._require_bus()
        try:
            write = i2c_msg.write(self.address, [reg])
            read = i2c_msg.read(self.address, 1)
            bus.i2c_rdwr(write, read)
            return list(read)[0]
        except OSError as exc:
            if getattr(exc, "errno", None) in (5, 6, 121):
                raise KW007NoDeviceError(
                    f"KW007 did not respond at I2C address 0x{self.address:02X}"
                ) from exc
            raise KW007Error(f"I2C read failed: {exc}") from exc

    def write_block(self, start_reg: int, data) -> None:
        payload = [start_reg] + [int(v) & 0xFF for v in data]
        bus = self._require_bus()
        try:
            msg = i2c_msg.write(self.address, payload)
            bus.i2c_rdwr(msg)
        except OSError as exc:
            if getattr(exc, "errno", None) in (5, 6, 121):
                raise KW007NoDeviceError(
                    f"KW007 did not respond at I2C address 0x{self.address:02X}"
                ) from exc
            raise KW007Error(f"I2C block write failed: {exc}") from exc

    def _rmw(self, reg: int, clear_mask: int, set_bits: int) -> None:
        value = self.read_reg(reg)
        value &= (~clear_mask) & 0xFF
        value |= set_bits & 0xFF
        self.write_reg(reg, value)

    def init(self) -> None:
        """
        Run the official KW007 initialization sequence:

        1. Reg9 = 0x10 to enter fuse mode.
        2. Read factory VCO bank from Reg1[5:0].
        3. Patch Reg12[5:0] with the VCO bank.
        4. Write Reg0..Reg30 with Reg9 = 0x30.

        R31 is deliberately not written.
        """
        self.write_reg(
            REG_MANUAL_MODE,
            DEFAULT_REGS[REG_MANUAL_MODE] & ~MASK_EFUSE_MODE,
        )

        vco_bank = self.read_reg(REG_VCO_FUSE) & MASK_VCO_BANK

        regs = list(DEFAULT_REGS)
        regs[REG_VCO_CTRL] = (
            (DEFAULT_REGS[REG_VCO_CTRL] & MASK_SAMPLE_RATE)
            | MASK_RESERVED_R12
            | vco_bank
        )

        self.write_block(0x00, regs)

    def read(self) -> KW007Data:
        flags = self.read_reg(REG_FLAGS)
        rssi = self.read_reg(REG_RSSI)

        return KW007Data(
            ok=True,
            approaching=bool(flags & FLAG_APPROACHING),
            leaving=bool(flags & FLAG_LEAVING),
            is_day=bool(flags & FLAG_DAY_NIGHT),
            rssi=rssi,
        )

    def set_detection_range(self, range_level: int) -> None:
        """
        Set one of the predefined range levels 1..8.

        Approximate levels:
          1 ~20cm, 2 ~50cm, 3 ~1m, 4 ~3m,
          5 ~5m, 6 ~7m, 7 ~10m, 8 ~12m enhanced.

        Each preset applies gain, threshold, sensitivity and enhanced mode.
        If custom sensitivity is required, call set_sensitivity() after this
        method because changing the range overwrites sensitivity.
        """
        if range_level not in _RANGE_PRESETS:
            raise ValueError("range_level must be from 1 to 8")

        amp1, amp2, amp3, threshold, sensitivity, enhanced = _RANGE_PRESETS[range_level]
        self.set_gain(amp1, amp2, amp3)
        self.set_threshold(threshold)
        self.set_sensitivity(sensitivity)
        self.set_enhanced_mode(enhanced)

    def set_gain(self, amp1: int, amp2: int, amp3: int) -> None:
        if not (0 <= amp1 <= 7):
            raise ValueError("amp1 must be 0..7")
        if not (0 <= amp2 <= 7):
            raise ValueError("amp2 must be 0..7")
        if not (0 <= amp3 <= 3):
            raise ValueError("amp3 must be 0..3")

        r19 = self.read_reg(REG_AMP1_GAIN)
        r20 = self.read_reg(REG_AMP2_AMP3_GAIN)

        r19 = (r19 & ~MASK_AMP1) | (amp1 << 5)
        r20 = (r20 & ~(MASK_AMP2 | MASK_AMP3)) | (amp3 << 3) | amp2

        self.write_reg(REG_AMP1_GAIN, r19)
        self.write_reg(REG_AMP2_AMP3_GAIN, r20)

    def set_threshold(self, threshold: int) -> None:
        if not 0 <= threshold <= 255:
            raise ValueError("threshold must be 0..255")
        self.write_reg(REG_THRESHOLD, threshold)

    def set_sensitivity(self, level: int) -> None:
        """
        Set motion sensitivity using Reg10[3:0].

        Valid values:
          0  = most sensitive
          15 = least sensitive

        Detection-range presets also set sensitivity. For fine tuning, call
        this method after set_detection_range().
        """
        if not 0 <= level <= 15:
            raise ValueError("sensitivity level must be 0..15")

        self._rmw(
            REG_SENSITIVITY,
            MASK_SENSITIVITY | MASK_SENSITIVITY_RSVD,
            level,
        )

    def set_enhanced_mode(self, enable: bool) -> None:
        self._rmw(
            REG_ENHANCED_MODE,
            MASK_ENHANCED,
            MASK_ENHANCED if enable else 0,
        )

    def set_gpo_delay(self, seconds: int) -> None:
        """
        Set KW007-SE GPO hold time.

        Valid values: 1, 16, 32, 64 seconds.
        """
        if seconds not in _GPO_DELAY_SECONDS_TO_SETTING:
            raise ValueError("KW007-SE GPO delay must be 1, 16, 32, or 64 seconds")

        setting = _GPO_DELAY_SECONDS_TO_SETTING[seconds]
        self._rmw(REG_GPO_DELAY, MASK_GPO_DELAY, setting << 1)

    def set_slow_speed_detection(self, enable: bool) -> None:
        # Reg21 bit5 is inverted: 0 = enabled, 1 = disabled.
        self._rmw(
            REG_SLOW_SPEED,
            MASK_SLOW_DET,
            0 if enable else MASK_SLOW_DET,
        )

    def set_fast_speed_detection(self, enable: bool) -> None:
        self._rmw(
            REG_GPO_DELAY,
            MASK_FAST_SPEED_DET,
            MASK_FAST_SPEED_DET if enable else 0,
        )

    def set_sampling_rate(self, hz: int) -> None:
        """
        Set the internal Doppler processing sample rate.

        Valid values:
          1000 = 1 kHz (default)
           500 = 500 Hz
        """
        if hz not in (500, 1000):
            raise ValueError("Sampling rate must be 500 or 1000 Hz")

        self._rmw(
            REG_VCO_CTRL,
            MASK_SAMPLE_RATE,
            MASK_SAMPLE_RATE if hz == 500 else 0,
        )

    def verify_reg(self, reg: int, mask: int, expected: int) -> bool:
        value = self.read_reg(reg)
        return (value & mask) == (expected & mask)
