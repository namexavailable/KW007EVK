"""
KW007 Motion Event Example — Raspberry Pi 4 / 5
Copyright 2026 Keywave Technology
SPDX-License-Identifier: Apache-2.0
"""

import time
from kw007 import KW007, KW007Error

try:
    with KW007(bus=1) as sensor:
        sensor.init()
        sensor.set_detection_range(4)

        print("KW007 Ready")

        last_approaching = False
        last_leaving = False

        while True:
            data = sensor.read()

            if data.approaching and not last_approaching:
                print("Approaching")

            if data.leaving and not last_leaving:
                print("Leaving")

            if data.motion:
                print(f"Motion detected, RSSI={data.rssi}")

            last_approaching = data.approaching
            last_leaving = data.leaving

            time.sleep(0.128)

except KW007Error as exc:
    print(f"KW007 error: {exc}")
