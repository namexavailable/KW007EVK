"""
KW007 Basic Read Example — Raspberry Pi 4 / 5
Copyright 2026 Keywave Technology
SPDX-License-Identifier: Apache-2.0
"""

import time
from kw007 import KW007, KW007Error

try:
    with KW007(bus=1) as sensor:
        sensor.init()
        sensor.set_detection_range(4)

        print("KW007 Ready")

        while True:
            data = sensor.read()

            print(
                f"Approaching={'YES' if data.approaching else 'NO'}  "
                f"Leaving={'YES' if data.leaving else 'NO'}  "
                f"RSSI={data.rssi}"
            )

            time.sleep(0.128)

except KW007Error as exc:
    print(f"KW007 error: {exc}")
