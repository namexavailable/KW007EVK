============================================================
 KW007 SDK v1.3 - STM32
 Keywave KW007 5.8 GHz Doppler Radar Motion Sensor
 Release Date: 2026-09-07
============================================================

PURPOSE
-------
This package provides the KW007 v1.3 C SDK with an STM32 HAL
implementation for STM32Cube / STM32 HAL projects.

PACKAGE CONTENTS
----------------
  SDK\
      KW007_api.c / .h       High-level user API
      kw007_reg.c / .h       Register-level implementation
      kw007_hal.h            HAL interface
      User_platform\
          kw007_hal_stm32.c  STM32 HAL implementation

  Examples\
      kw007_example_led.c    Minimal motion-driven application

  Docs\
      KW007_Programming_Guide_v2.0c.pdf
      README.txt

GETTING STARTED - STM32
-----------------------
1. Generate and configure an I2C peripheral in STM32CubeMX /
   STM32CubeIDE, for example I2C1 / hi2c1.

2. Add these files to the project:

      SDK\KW007_api.c
      SDK\kw007_reg.c
      SDK\User_platform\kw007_hal_stm32.c

3. Add SDK\ and SDK\User_platform\ to the compiler include paths.

4. In kw007_hal_stm32.c, replace:

      #include "stm32xxxx_hal.h"

   with the HAL header for the selected STM32 family, for example:

      #include "stm32f4xx_hal.h"

5. Before KW007_Init(), assign the I2C handle:

      KW007_HAL_SetI2C(&hi2c1);

6. Initialize and configure the sensor:

      if (KW007_Init() != KW007_OK) {
          // handle error
      }

      KW007_SetDetectionRange(4);

      KW007_Data data = KW007_Read();

      if (data.approaching) {
          // approaching motion
      }

HARDWARE REQUIREMENT - RANGE1
-----------------------------
For I2C / software-control mode, connect Range1 DIRECTLY TO GND
before power-up.

Do not use a series resistor on Range1 in software-control mode.
A resistor is used for hardware range selection; direct GND selects
I2C control.

POWER
-----
Use either the KW007 3.3 V input or 5 V input, never both.
3.3 V is recommended when interfacing to a 3.3 V STM32 system.

I2C ADDRESS
-----------
KW007 7-bit address: 0x19

STM32 HAL_I2C_Mem_Read / HAL_I2C_Mem_Write expect the shifted
address form, so the supplied STM32 HAL passes 0x32.

DETECTION RANGE - SDK v1.3
--------------------------
Range  Approx.   Amp1  Amp2  Amp3  Threshold  Sensitivity  Enhanced
  1    ~20 cm      4     0     0       80          2          Off
  2    ~50 cm      6     0     0       80          2          Off
  3    ~1 m        4     5     0       80          2          Off
  4    ~3 m        7     4     0       80          4          Off
  5    ~5 m        7     7     0       90          8          Off
  6    ~7 m        7     7     1       64          8          Off
  7    ~10 m       7     7     3       32          8          Off
  8    ~12 m       7     7     3       32          8          On

KW007_SetDetectionRange() applies gain, threshold, sensitivity and
enhanced mode together.

Ranges 1-3 reproduce the sensor hardware range-selection behaviour.
Ranges 4-8 are software-control presets provided by the SDK.

SENSITIVITY
-----------
Fine tuning is available with:

      KW007_SetSensitivity(level);

Valid values:
      0  = most sensitive
      15 = least sensitive

Call KW007_SetSensitivity() AFTER KW007_SetDetectionRange() if a
custom sensitivity is required because the range preset overwrites it.

GPO DELAY - KW007-SE
--------------------
      1 s  -> Reg29[2:1] = 10
     16 s  -> Reg29[2:1] = 00
     32 s  -> Reg29[2:1] = 01
     64 s  -> Reg29[2:1] = 11

REGISTER SAFETY
---------------
KW007_Init() writes R00-R30 only.

Do not write R31.

REQUIREMENTS
------------
C99 compiler and STM32 HAL library.

The core driver uses no dynamic memory and no floating point.

LICENSING
---------
Copyright 2026 Keywave Technology.

The first-party source code and documentation in this package are
licensed under the Apache License, Version 2.0.
See LICENSE for the complete license text.

SUPPORT
-------
For technical inquiries regarding the KW007 sensor or SDK,
please contact your Keywave representative.
