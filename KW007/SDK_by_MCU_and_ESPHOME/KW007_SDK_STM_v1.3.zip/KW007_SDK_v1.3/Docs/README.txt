============================================================
 KW007 SDK v1.3 - STM32 Technical Documentation
 Keywave KW007 5.8 GHz Doppler Radar Sensor
 Release Date: 2026-09-07
============================================================

CONTENTS
--------
  KW007_Programming_Guide_v2.0c.pdf
      Register-level reference for the KW007 sensor.

  ..\SDK\KW007_api.h
      Current v1.3 high-level API reference and detection-range table.

  ..\SDK\kw007_reg.h
      Current v1.3 register definitions and engineer API.

IMPORTANT v1.3 NOTES
--------------------
For I2C / software-control mode, Range1 must be connected directly
to GND before power-up. Do not use a series resistor.

KW007_SetDetectionRange() in SDK v1.3 applies gain, threshold,
sensitivity and enhanced mode.

Range 1 is approximately 20 cm and Range 8 approximately 12 m.

KW007_Init() writes R00-R30 only. Do not write R31.

The generated v1.2 HTML API reference has been removed from this
package so that an older generated API reference is not distributed
as v1.3 documentation.

LICENSING
---------
Copyright 2026 Keywave Technology.
See ..\LICENSE and ..\THIRD_PARTY_NOTICES.txt.
