# Changelog

## v1.3 - 2026-09-07

- Updated core KW007 SDK source to v1.3.
- Updated detection-range presets.
- Added sensitivity control through R10 and `KW007_SetSensitivity()`.
- Detection-range presets now apply gain, threshold, sensitivity and enhanced mode.
- Updated Range 1 to approximately 20 cm.
- Updated Range 8 to approximately 12 m.
- Updated Range1 requirement to direct GND for I2C/software-control mode.
- Clarified R31 must not be written; initialization writes R00-R30 only.
- Updated STM32 HAL package version and STM32 integration README.
- Removed generated v1.2 HTML API files to avoid mixing stale API documentation into the v1.3 release.
