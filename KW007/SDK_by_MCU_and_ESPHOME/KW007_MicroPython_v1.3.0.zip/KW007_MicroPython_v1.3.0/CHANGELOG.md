# Changelog

## v1.3.0 - 2026-09-07

- Updated detection-range presets to match KW007 SDK v1.3.
- Added sensitivity control using Reg10[3:0].
- Added `set_sensitivity(level)` with valid range 0-15.
- Detection-range presets now apply gain, threshold, sensitivity and enhanced mode.
- Updated Range 1 to approximately 20 cm.
- Updated Range 8 to approximately 12 m.
- Updated Range1 wiring requirement: connect directly to GND before power-up for I2C/software-control mode.
- Clarified that initialization writes R00-R30 only and does not write R31.
