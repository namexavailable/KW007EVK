# Keywave KW007 MicroPython SDK v1.3.0

MicroPython driver for the Keywave KW007 5.8 GHz Doppler radar motion sensor.

This package is intended for MicroPython boards that provide `machine.I2C`. The included examples use Raspberry Pi Pico / Pico 2 W with:

```text
GP4 = SDA
GP5 = SCL
```

The driver uses the same KW007 initialization flow and register configuration as the Keywave C / Arduino SDK.

## 1. Package contents

```text
KW007_MicroPython_v1.3.0/
|
|-- README.md
|-- LICENSE
|-- kw007.py
|
`-- examples/
    |-- i2c_scan.py
    |-- basic_read.py
    `-- motion_led.py
```

## 2. Copy files to your board

Copy:

```text
kw007.py
```

to the MicroPython board filesystem.

Then copy the example you want to run, or create your own `main.py`.

For example with Thonny, upload `kw007.py` to the root of the Pico filesystem.

## 3. Hardware connection

Example for Raspberry Pi Pico / Pico 2 W:

| Pico | KW007 |
|---|---|
| GP4 | SDA |
| GP5 | SCL |
| GND | GND |
| 3V3 | KW007 3.3V input |

Also connect:

```text
KW007 Range1 -> GND
```

before power-up for I2C/software-control mode. Connect Range1 directly to GND; do not use a series resistor in software-control mode.

Use either the KW007 3.3V input or 5V input, never both. 3.3V is recommended for Pico.

## 4. Create the I2C interface

```python
from machine import I2C, Pin

i2c = I2C(
    0,
    sda=Pin(4),
    scl=Pin(5),
    freq=400000
)
```

## 5. Check that KW007 is detected

Run:

```python
print(i2c.scan())
```

A correctly connected KW007 should appear as:

```text
[25]
```

because:

```text
25 decimal = 0x19
```

You can also run:

```text
examples/i2c_scan.py
```

Expected output:

```text
KW007 found at 0x19
```

## 6. Basic use

```python
from machine import I2C, Pin
from kw007 import KW007

i2c = I2C(
    0,
    sda=Pin(4),
    scl=Pin(5),
    freq=400000
)

sensor = KW007(i2c)

sensor.init()
sensor.set_detection_range(4)

data = sensor.read()

print(data["approaching"])
print(data["leaving"])
print(data["rssi"])
```

## 7. BasicRead example

Run:

```text
examples/basic_read.py
```

Expected output:

```text
KW007 Ready
Approaching=NO  Leaving=NO  RSSI=32
Approaching=YES Leaving=NO  RSSI=140
Approaching=NO  Leaving=YES RSSI=118
```

Move toward and away from the sensor to test the direction flags.

## 8. MotionLED example

Run:

```text
examples/motion_led.py
```

Expected behavior:

```text
Approaching -> LED blinks twice
Leaving     -> LED blinks once
```

The example uses:

```python
Pin("LED", Pin.OUT)
```

which is suitable for Pico/Pico 2 W MicroPython builds that expose the onboard LED as `"LED"`.

If your board uses a different LED GPIO, change:

```python
LED_PIN = "LED"
```

to a GPIO number, for example:

```python
LED_PIN = 15
```

and use an external LED if needed.

## 9. Detect motion without direction

```python
data = sensor.read()

if data["motion"]:
    print("Motion detected")
```

`motion` is true when either `approaching` or `leaving` is true.

This is a motion indication, not a dedicated stationary-presence or occupancy flag.

## 10. Detection range

```python
sensor.set_detection_range(4)
```

Available presets:

| Setting | Approximate distance |
|---:|---:|
| 1 | ~20 cm |
| 2 | ~50 cm |
| 3 | ~1 m |
| 4 | ~3 m |
| 5 | ~5 m |
| 6 | ~7 m |
| 7 | ~10 m |
| 8 | ~12 m, enhanced mode |

Actual range depends on installation, target size, obstruction, motion, power quality, and environment.

Each range preset applies gain, threshold, sensitivity and enhanced mode together.

| Setting | Amp1 | Amp2 | Amp3 | Threshold | Sensitivity | Enhanced |
|---:|---:|---:|---:|---:|---:|:---:|
| 1 | 4 | 0 | 0 | 80 | 2 | Off |
| 2 | 6 | 0 | 0 | 80 | 2 | Off |
| 3 | 4 | 5 | 0 | 80 | 2 | Off |
| 4 | 7 | 4 | 0 | 80 | 4 | Off |
| 5 | 7 | 7 | 0 | 90 | 8 | Off |
| 6 | 7 | 7 | 1 | 64 | 8 | Off |
| 7 | 7 | 7 | 3 | 32 | 8 | Off |
| 8 | 7 | 7 | 3 | 32 | 8 | On |

Ranges 1-3 reproduce the sensor hardware range-selection behaviour. Ranges 4-8 are software-control presets provided by the SDK.

## 11. Main configuration commands

```python
sensor.init()
sensor.read()
sensor.set_detection_range(4)
sensor.set_threshold(90)
sensor.set_sensitivity(4)
sensor.set_enhanced_mode(True)
sensor.set_gpo_delay(16)
sensor.set_slow_speed_detection(True)
sensor.set_fast_speed_detection(True)
sensor.set_sampling_rate(1000)
```

### Threshold

```python
sensor.set_threshold(90)
```

Valid range:

```text
0 to 255
```

Lower values generally increase sensitivity. Higher values generally reduce sensitivity.

For normal use, start with `set_detection_range()` rather than tuning threshold manually.

### Sensitivity

```python
sensor.set_sensitivity(4)
```

Valid values are `0` to `15`:

- `0` = most sensitive
- `15` = least sensitive

`set_detection_range()` sets sensitivity as part of the preset. If you want to fine-tune sensitivity, call `set_sensitivity()` **after** `set_detection_range()`.

### GPO delay — KW007-SE

```python
sensor.set_gpo_delay(1)
sensor.set_gpo_delay(16)
sensor.set_gpo_delay(32)
sensor.set_gpo_delay(64)
```

Mapping:

| Hold time | Reg29[2:1] |
|---:|---|
| 16 s | 00 |
| 32 s | 01 |
| 1 s | 10 |
| 64 s | 11 |

### Sampling rate

```python
sensor.set_sampling_rate(1000)  # 1 kHz, default
sensor.set_sampling_rate(500)   # 500 Hz
```

This is the KW007 internal Doppler processing sampling rate. It is not the MicroPython loop or polling rate.

For normal applications, keep the default 1 kHz setting.

## 12. Returned data

```python
data = sensor.read()
```

Returns a dictionary:

```python
{
    "ok": True,
    "approaching": False,
    "leaving": False,
    "is_day": True,
    "rssi": 42,
    "motion": False
}
```

## 13. Direct register access

Advanced users can use:

```python
value = sensor.read_reg(5)
sensor.write_reg(27, 90)
```

For normal applications, use the high-level API instead.

## 14. Troubleshooting

### KW007 not found at 0x19

Check:

1. SDA / SCL wiring.
2. Common GND.
3. Sensor power.
4. Range1 is connected directly to GND before power-up.
5. Your selected I2C bus and GPIO pins are valid for the board.
6. `i2c.scan()` shows `0x19`.

### BasicRead starts but values do not change

Check:

1. `sensor.init()` completed successfully.
2. Detection range is suitable.
3. The sensor is facing the moving target.
4. Move toward or away from the sensor rather than only sideways.

## 15. License

Copyright 2026 Keywave Technology.

Licensed under the Apache License, Version 2.0.

See `LICENSE`.
