"""
KW007 MicroPython Motion LED Example
Raspberry Pi Pico / Pico 2 W

Approaching -> blink twice
Leaving     -> blink once

Copyright 2026 Keywave Technology
SPDX-License-Identifier: Apache-2.0
"""

from machine import I2C, Pin
from time import sleep_ms
from kw007 import KW007

SDA_PIN = 4
SCL_PIN = 5

# Change this if your board/core uses another LED GPIO.
LED_PIN = "LED"

i2c = I2C(
    0,
    sda=Pin(SDA_PIN),
    scl=Pin(SCL_PIN),
    freq=400000
)

led = Pin(LED_PIN, Pin.OUT)

sensor = KW007(i2c)

if not sensor.scan_present():
    raise RuntimeError("KW007 not found at I2C address 0x19")

sensor.init()
sensor.set_detection_range(4)

print("KW007 Ready")

last_approaching = False
last_leaving = False


def blink(times):
    for _ in range(times):
        led.on()
        sleep_ms(150)
        led.off()
        sleep_ms(150)


while True:
    data = sensor.read()

    if data["approaching"] and not last_approaching:
        print("Approaching")
        blink(2)

    if data["leaving"] and not last_leaving:
        print("Leaving")
        blink(1)

    last_approaching = data["approaching"]
    last_leaving = data["leaving"]

    sleep_ms(128)
