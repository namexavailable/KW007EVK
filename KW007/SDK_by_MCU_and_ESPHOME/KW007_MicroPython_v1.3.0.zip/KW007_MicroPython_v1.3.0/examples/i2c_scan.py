"""
KW007 MicroPython I2C Scan Example
Copyright 2026 Keywave Technology
SPDX-License-Identifier: Apache-2.0
"""

from machine import I2C, Pin

SDA_PIN = 4
SCL_PIN = 5

i2c = I2C(
    0,
    sda=Pin(SDA_PIN),
    scl=Pin(SCL_PIN),
    freq=400000
)

devices = i2c.scan()

print("I2C devices:")
for address in devices:
    print("  0x{:02X}".format(address))

if 0x19 in devices:
    print("KW007 found at 0x19")
else:
    print("KW007 not found")
