# Changelog

## 1.3.0 Pico 2 W package

- Updated core KW007 SDK source to v1.3.
- Updated detection-range presets.
- Added sensitivity support through R10 and `KW007_SetSensitivity()`.
- Detection-range presets now apply gain, threshold, sensitivity and enhanced mode.
- Updated Range 1 to approximately 20 cm.
- Updated Range 8 to approximately 12 m.
- Updated Range1 requirement to direct GND for I2C/software-control mode.
- Clarified R31 must not be written; initialization writes R00-R30 only.
- Preserved the improved Arduino/Pico Wire HAL implementation from the previous package.
- Updated Pico 2 W documentation and package metadata.


## 1.2.0 Arduino package

- Packaged the KW007 v1.2 core driver as an installable Arduino library.
- Added `KW007.h` as the Arduino-friendly public include.
- Added Arduino IDE examples: `BasicRead` and `MotionLED`.
- Added Arduino Library Manager metadata (`library.properties`) and keywords.
- Preserved Apache-2.0 license headers on supplied Keywave source files.
- Corrected the malformed `KW007_SDK_VERSION` macro line in `KW007_api.h` so the header compiles.
- Added an explicit `Arduino.h` include in the Arduino HAL.
- Arduino HAL now maps Wire address-NACK status to `KW007_ERR_NO_DEVICE`, consistent with the public API documentation.
