/*
 * ============================================================
 *  Pico2W_MotionLED.ino — KW007 Motion LED Example for Pico 2 W
 *  Keywave KW007 5.8GHz Doppler Radar Sensor
 *  KW007 Arduino Library v1.3.0
 *
 *  Copyright 2026 Keywave Technology
 *  SPDX-License-Identifier: Apache-2.0
 *  Licensed under the Apache License, Version 2.0; see LICENSE.
 *
 *  Example wiring:
 *    Pico 2 W GP4  -> KW007 SDA
 *    Pico 2 W GP5  -> KW007 SCL
 *    Pico 2 W GND  -> KW007 GND
 *    Pico 2 W 3V3  -> KW007 3.3V input
 *
 *  IMPORTANT:
 *    - KW007 Range1 must be connected to GND through
 *      approximately 1 kOhm before power-up for I2C mode.
 *    - Use either the KW007 3.3V input or 5V input, never both.
 *
 *  LED behavior:
 *    Approaching -> blink twice
 *    Leaving     -> blink once
 * ============================================================
 */

#include <Wire.h>
#include <KW007.h>

#define SDA_PIN 4
#define SCL_PIN 5

/*
 * Raspberry Pi Pico 2 W onboard LED:
 * In the Arduino core, LED_BUILTIN should map to the onboard LED.
 * If your board/core does not support it, replace LED_PIN with
 * another GPIO connected to an external LED.
 */
#define LED_PIN LED_BUILTIN

static bool lastApproaching = false;
static bool lastLeaving = false;

void blinkLED(uint8_t times)
{
    for (uint8_t i = 0; i < times; i++)
    {
        digitalWrite(LED_PIN, HIGH);
        delay(150);

        digitalWrite(LED_PIN, LOW);
        delay(150);
    }
}

void setup()
{
    Serial.begin(115200);
    delay(1000);

    pinMode(LED_PIN, OUTPUT);
    digitalWrite(LED_PIN, LOW);

    Serial.println("KW007 Pico 2 W MotionLED");

    // Pico 2 W: assign I2C pins before starting Wire.
    Wire.setSDA(SDA_PIN);
    Wire.setSCL(SCL_PIN);
    Wire.begin();

    uint8_t status = KW007_Init();

    if (status != KW007_OK)
    {
        Serial.print("KW007_Init failed, status=0x");
        Serial.println(status, HEX);

        // Fast blink indicates initialization failure.
        while (true)
        {
            digitalWrite(LED_PIN, HIGH);
            delay(100);
            digitalWrite(LED_PIN, LOW);
            delay(100);
        }
    }

    status = KW007_SetDetectionRange(4);

    if (status != KW007_OK)
    {
        Serial.print("KW007_SetDetectionRange failed, status=0x");
        Serial.println(status, HEX);

        while (true)
        {
            delay(1000);
        }
    }

    Serial.println("KW007 Ready");
}

void loop()
{
    KW007_Data data = KW007_Read();

    if (!data.ok)
    {
        Serial.println("KW007 read error");
        delay(128);
        return;
    }

    // Trigger once when approaching changes from false to true.
    if (data.approaching && !lastApproaching)
    {
        Serial.println("Approaching");
        blinkLED(2);
    }

    // Trigger once when leaving changes from false to true.
    if (data.leaving && !lastLeaving)
    {
        Serial.println("Leaving");
        blinkLED(1);
    }

    lastApproaching = data.approaching;
    lastLeaving = data.leaving;

    delay(128);
}
