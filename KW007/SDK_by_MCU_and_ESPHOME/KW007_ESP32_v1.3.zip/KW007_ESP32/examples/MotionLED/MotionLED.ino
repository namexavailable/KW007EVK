#include <Wire.h>
#include <KW007.h>

// Change these for your ESP32 board
#define SDA_PIN 8
#define SCL_PIN 9

// Change this to the GPIO connected to your LED.
// If your board has a known onboard LED pin, use that instead.
#define LED_PIN 2

static bool lastApproaching = false;
static bool lastLeaving = false;

void blinkLED(uint8_t times)
{
    for (uint8_t i = 0; i < times; i++) {
        digitalWrite(LED_PIN, HIGH);
        delay(150);

        digitalWrite(LED_PIN, LOW);
        delay(150);
    }
}

void setup()
{
    Serial.begin(115200);

    pinMode(LED_PIN, OUTPUT);
    digitalWrite(LED_PIN, LOW);

    // ESP32: specify SDA and SCL pins
    Wire.begin(SDA_PIN, SCL_PIN);

    Serial.println("KW007 ESP32 Motion LED Example");

    uint8_t status = KW007_Init();

    if (status != KW007_OK) {
        Serial.print("KW007 init failed, status=0x");
        Serial.println(status, HEX);

        // Fast blinking indicates initialization failure
        while (1) {
            digitalWrite(LED_PIN, HIGH);
            delay(100);
            digitalWrite(LED_PIN, LOW);
            delay(100);
        }
    }

    status = KW007_SetDetectionRange(4);

    if (status != KW007_OK) {
        Serial.print("Set range failed, status=0x");
        Serial.println(status, HEX);
    }

    Serial.println("KW007 Ready");
}

void loop()
{
    KW007_Data data = KW007_Read();

    if (!data.ok) {
        Serial.println("KW007 read error");
        delay(128);
        return;
    }

    // Approaching = blink twice
    if (data.approaching && !lastApproaching) {
        Serial.println("Approaching");
        blinkLED(2);
    }

    // Leaving = blink once
    if (data.leaving && !lastLeaving) {
        Serial.println("Leaving");
        blinkLED(1);
    }

    lastApproaching = data.approaching;
    lastLeaving = data.leaving;

    delay(128);
}