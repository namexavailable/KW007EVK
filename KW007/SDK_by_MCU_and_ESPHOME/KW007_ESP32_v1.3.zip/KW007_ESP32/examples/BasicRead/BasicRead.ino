/**
 * ============================================================
 *  BasicRead.ino — Minimal Arduino Example
 *  Keywave KW007 5.8GHz Doppler Radar Sensor
 *  KW007_SDK_v1.3
 *  Released: 2026-08-24
 *
 *  Copyright 2026 Keywave Technology
 *  SPDX-License-Identifier: Apache-2.0
 *  Licensed under the Apache License, Version 2.0; see LICENSE.
 * ============================================================
 */

#include <Wire.h>
#include <KW007.h>

void setup()
{
    Serial.begin(115200);
    Wire.begin();

    uint8_t status = KW007_Init();
    if (status != KW007_OK)
    {
        Serial.print("KW007_Init failed, status=0x");
        Serial.println(status, HEX);
        while (true) { delay(1000); }
    }

    status = KW007_SetDetectionRange(4);  // approximately 3 m
    if (status != KW007_OK)
    {
        Serial.print("Set range failed, status=0x");
        Serial.println(status, HEX);
        while (true) { delay(1000); }
    }

    Serial.println("KW007 ready");
}

void loop()
{
    KW007_Data data = KW007_Read();

    if (!data.ok)
    {
        Serial.println("KW007 read failed");
        delay(128);
        return;
    }

    Serial.print("Approaching=");
    Serial.print(data.approaching ? "YES" : "NO");
    Serial.print("  Leaving=");
    Serial.print(data.leaving ? "YES" : "NO");
    Serial.print("  RSSI=");
    Serial.println(data.rssi);

    delay(128);
}
