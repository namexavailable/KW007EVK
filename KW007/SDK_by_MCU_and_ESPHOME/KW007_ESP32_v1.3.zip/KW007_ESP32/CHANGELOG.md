# Changelog

## v1.3.0 - 2026-09-07

- Updated core KW007 SDK source to v1.3.
- Updated detection-range presets.
- Added sensitivity support through R10 and `KW007_SetSensitivity()`.
- Detection-range presets now apply gain, threshold, sensitivity and enhanced mode.
- Updated Range 1 to approximately 20 cm.
- Updated Range 8 to approximately 12 m.
- Updated Range1 requirement to direct GND for I2C/software-control mode.
- Clarified R31 must not be written; initialization writes R00-R30 only.
- Preserved the improved Arduino/ESP32 Wire HAL implementation from the previous package.
- Updated ESP32 documentation and package metadata.
