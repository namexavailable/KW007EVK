/**
 * ============================================================
 *  KW007_api.h — User API
 *  Keywave KW007 5.8GHz Doppler Radar Sensor
 *  KW007_SDK_v1.3
 *  Released: 2026-09-07
 *
 *  Copyright 2026 Keywave Technology
 *  SPDX-License-Identifier: Apache-2.0
 *  Licensed under the Apache License, Version 2.0; see LICENSE.
 *
 *  High-level functions for application developers.
 *  No register knowledge required.
 *
 *  For direct register access or fine-grained gain control,
 *  include kw007_reg.h additionally.
 *
 *  Supported platforms (provide HAL implementation):
 *    ESP32 / ESP32-S3 / ESP32-C3  — kw007_hal_arduino.cpp
 *    Arduino AVR / SAMD / nRF52   — kw007_hal_arduino.cpp
 *    STM32 (HAL / LL)             — kw007_hal_stm32.c
 *    Windows + FTDI               — kw007_hal_ftdi.cpp
 *    Any MCU with I2C             — kw007_hal_user.c (template)
 *
 *  HARDWARE REQUIREMENT (I2C / software control mode):
 *    The Range1 pin MUST be connected directly to GND before power-up.
 *    No series resistor - a resistor is a range setting, and 0 ohms is
 *    the combination that selects I2C control.
 *    This switches the sensor into I2C-controlled mode; otherwise
 *    the chip runs in hardware (pin-select) mode and ignores
 *    register writes.
 *
 *    Use either the 3.3 V or the 5 V input, never both, and never
 *    apply 5 V to the 3.3 V input - doing so will damage the module.
 *
 *  BASIC USAGE:
 *    KW007_Init();
 *    KW007_SetDetectionRange(4);
 *    KW007_Data data = KW007_Read();
 *    if (data.approaching) { ... }
 * ============================================================
 */

#ifndef KW007_API_H
#define KW007_API_H

#include <stdint.h>
#include <stdbool.h>
#include "kw007_hal.h"   /* provides KW007_OK / KW007_ERR_* return codes */

/* ─── SDK VERSION ─────────────────────────────────────────────
 * Readable by the preprocessor, so application code can adapt:
 *   #if KW007_SDK_VERSION >= KW007_SDK_VERSION_AT(1,3)
 * ───────────────────────────────────────────────────────────── */
#define KW007_SDK_VERSION_MAJOR   1
#define KW007_SDK_VERSION_MINOR   3
#define KW007_SDK_VERSION_STRING  "1.3"
#define KW007_SDK_VERSION_AT(ma, mi)  (((ma) << 8) | (mi))
#define KW007_SDK_VERSION \
        KW007_SDK_VERSION_AT(KW007_SDK_VERSION_MAJOR, KW007_SDK_VERSION_MINOR)

#ifdef __cplusplus
extern "C" {
#endif

/* ─── GPO DELAY DURATION ───────────────────────────────────── */
/**
 * GPO pin hold-on time after motion stops.
 * Encoded in R29 bits[2:1].
 *
 *   R29[2:1]  │ Hold time
 *   ──────────┼───────────
 *      00     │   16 s
 *      01     │   32 s
 *      10     │    1 s
 *      11     │   64 s
 */
typedef enum {
    DELAY_SETTING1 = 0,   /* 00 — 16 s */
    DELAY_SETTING2 = 1,   /* 01 — 32 s */
    DELAY_SETTING3 = 2,   /* 10 —  1 s */
    DELAY_SETTING4 = 3    /* 11 — 64 s */
} KW007_DelayDuration;

/* ─── DATA OUTPUT ──────────────────────────────────────────── */
typedef struct {
    bool    ok;           /* false = I2C read failed                  */
    bool    approaching;  /* object approaching                       */
    bool    leaving;      /* object leaving                           */
    bool    isDay;        /* 1=operating, 0=rest                      */
    uint8_t rssi;         /* signal strength 0-255                    */
} KW007_Data;

/* ─── API ──────────────────────────────────────────────────── */

/**
 * Initialize sensor. Runs the official startup sequence.
 *
 * @pre The Range1 pin MUST be connected directly to GND before power-up,
 *      with no series resistor, to enable I2C / software control mode.
 *      If Range1 is left floating, or tied through a resistor, the sensor
 *      runs in hardware (pin-select) mode and all register writes are
 *      silently ignored.
 *
 * @return KW007_OK            Success
 * @return KW007_ERR_I2C       I2C bus failure
 * @return KW007_ERR_NO_DEVICE Sensor did not ACK (check wiring,
 *                             Range1 pin, and power supply)
 */
uint8_t KW007_Init(void);

/**
 * Read sensor output. Sensor updates at ~8Hz; poll in main loop.
 * Returns data.ok = false on I2C failure.
 */
KW007_Data KW007_Read(void);

/**
 * Set detection range 1 (close) ~ 8 (far).
 * Sets gain (amp1 / amp2 / amp3), threshold, sensitivity and enhanced mode.
 *
 * Register mapping:
 *   amp1        → R19[7:5]   (REG_AMP1_GAIN)
 *   amp2        → R20[2:0]   (REG_AMP2_AMP3_GAIN)
 *   amp3        → R20[4:3]   (REG_AMP2_AMP3_GAIN)
 *   Threshold   → R27        (REG_THRESHOLD)
 *   Sensitivity → R10[3:0]   (REG_SENSITIVITY)
 *   Enhanced    → R24[6]     (REG_ENHANCED_MODE)
 *
 * Ranges 1-3 reproduce what the sensor does in hardware (pin-select) mode,
 * so switching a design from the range pins to I2C keeps the same
 * behaviour. Ranges 4-8 go beyond anything the pins can select; their gains
 * carry over unchanged from SDK v1.2, with only the threshold and
 * sensitivity lowered.
 *
 * Approximate detection distance (stable power supply, no obstruction,
 * human target):
 *
 *   Range │  amp1      amp2      amp3    │ Thresh │ Sens │ Enh │ ~Distance
 *         │ R19[7:5]  R20[2:0]  R20[4:3] │  R27   │ R10  │ R24 │
 *   ──────┼──────────────────────────────┼────────┼──────┼─────┼──────────
 *     1   │    4         0         0     │   80   │   2  │ off │  ~20 cm
 *     2   │    6         0         0     │   80   │   2  │ off │  ~50 cm
 *     3   │    4         5         0     │   80   │   2  │ off │   ~1 m
 *     4   │    7         4         0     │   80   │   4  │ off │   ~3 m
 *     5   │    7         7         0     │   90   │   8  │ off │   ~5 m
 *     6   │    7         7         1     │   64   │   8  │ off │   ~7 m
 *     7   │    7         7         3     │   32   │   8  │ off │  ~10 m
 *     8   │    7         7         3     │   32   │   8  │ on  │  ~12 m
 *
 * The sensitivity is part of the preset, so call KW007_SetSensitivity()
 * after this function to fine-tune it - calling it first has no effect,
 * because the preset overwrites it.
 *
 * The settings are written one after another rather than as a single
 * transaction. A failure part way through leaves the earlier writes in
 * place and returns the HAL's status.
 *
 * Actual range varies with power-supply stability, physical obstruction,
 * target size, and motion speed. Unstable VDD or RF interference can
 * significantly reduce effective distance.
 */
uint8_t KW007_SetDetectionRange(uint8_t range);

/**
 * Set amplifier gains directly.
 *   amp1 : 0–7  → R19[7:5] (REG_AMP1_GAIN)
 *   amp2 : 0–7  → R20[2:0] (REG_AMP2_AMP3_GAIN)
 *   amp3 : 0–3  → R20[4:3] (REG_AMP2_AMP3_GAIN)
 *
 * @return KW007_ERR_PARAM if any value is out of range.
 */
uint8_t KW007_SetGain(uint8_t amp1, uint8_t amp2, uint8_t amp3);

/**
 * Set detection threshold. Higher value = less sensitive.
 *   threshold : 0–255  → R27[7:0] (REG_THRESHOLD)
 *
 * Choosing a value: the threshold is compared against the reflected signal
 * strength, which the KW007 GUI plots on the same 0-255 scale. With the
 * area empty the chart shows the noise floor; with a target moving at the
 * maximum required distance it shows the level the threshold must stay
 * under. Set it between the two. Changing the gain moves both readings, so
 * re-check afterwards. The Programming Guide has the full procedure.
 */
uint8_t KW007_SetThreshold(uint8_t threshold);

/**
 * Enable / disable enhanced range mode.
 *   enable : true = ON, false = OFF  → R24[6] (REG_ENHANCED_MODE)
 */
uint8_t KW007_SetEnhancedMode(bool enable);

/**
 * Set GPO output hold time after motion stops.
 *   delay : KW007_DelayDuration  → R29[2:1] (REG_GPO_DELAY, MASK_GPO_DELAY)
 *
 * The four durations are listed with @ref KW007_DelayDuration.
 */
uint8_t KW007_SetGPO_DelayDuration(KW007_DelayDuration delay);

/**
 * Enable / disable slow-speed motion detection.
 *   enable : true = ON, false = OFF  → R21[5] (REG_SLOW_SPEED)
 *
 * @note Hardware logic is inverted: bit[5]=0 enables slow detect,
 *       bit[5]=1 disables it. This API hides the inversion.
 */
uint8_t KW007_SetSlowSpeedDetection(bool enable);

/**
 * Enable / disable fast-speed motion detection.
 *   enable : true = ON, false = OFF (default)
 *            → R29[0] (REG_GPO_DELAY, MASK_FAST_SPEED_DET)
 */
uint8_t KW007_SetFastSpeedDetection(bool enable);

/**
 * Set system sampling rate.
 *   use500Hz : false = 1 kHz (default), true = 500 Hz
 *              → R12[7] (REG_VCO_CTRL, MASK_SAMPLE_RATE)
 */
uint8_t KW007_SetSamplingRate(bool use500Hz);

/**
 * Set motion sensitivity.
 *   level : 0 (most sensitive) - 15 (least)
 *           → R10[3:0] (REG_SENSITIVITY, MASK_SENSITIVITY)
 *
 * Higher value = less sensitive. Level 0 responds to the smallest movement
 * and level 15 needs the largest; the sixteen steps are evenly spaced.
 *
 * This is a separate control from KW007_SetThreshold(). The threshold works
 * on how strong the reflection is; this works on how far the target moved.
 * A target that is close but barely moving is rejected here, not there.
 *
 * KW007_Init() leaves the sensitivity at 8, and
 * KW007_SetDetectionRange() sets it as part of its preset - 2 for ranges
 * 1-3, 4 for range 4, 8 for ranges 5-8. Call this function after the range,
 * not before, or the preset overwrites it.
 *
 * @pre KW007_Init() must have run. It sets R09[5], which is what routes
 *      R10 to the I2C register instead of the factory fuse; before that
 *      write this setting has no effect.
 *
 * @note The call also holds R10[5:4] at 0. That field is fixed in hardware,
 *       and tying Range1 to GND - already mandatory for software control -
 *       fixes it at 0. A register value that disagreed with the pin would
 *       not be honoured.
 *
 * @return KW007_ERR_PARAM if level is greater than 15.
 */
uint8_t KW007_SetSensitivity(uint8_t level);

#ifdef __cplusplus
}
#endif

#endif /* KW007_API_H */
