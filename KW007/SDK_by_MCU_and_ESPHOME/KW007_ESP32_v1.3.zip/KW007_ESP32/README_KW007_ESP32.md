# Keywave KW007 ESP32 Arduino Library v1.3.0

Arduino IDE library for using the Keywave KW007 5.8 GHz Doppler radar motion sensor with ESP32-family boards.

This package is intended for users who want to work with KW007 through the Arduino IDE. You do not need to rename, move, or manually copy source files after installing the ZIP library.

---

## 1. Install the library

1. Download `KW007_ESP32_v1.3.0.zip`.
2. Open **Arduino IDE**.
3. Select **Sketch > Include Library > Add .ZIP Library...**
4. Select the downloaded ZIP file.
5. Open **File > Examples > Keywave KW007 > BasicRead**.

If the example opens correctly, the library has been installed.

---

## 2. Hardware setup

### Important: Range1 pin

For I2C / software control, the **Range1 pin must be connected to GND directly before power-up**.

If Range1 is not connected correctly, the KW007 stays in hardware pin-selection mode and ignores I2C configuration commands.

The KW007 Programming Guide recommends approximately **1 kΩ**.

### Power

Use **either** the module's 3.3 V input **or** 5 V input.

- Do not connect both power inputs at the same time.
- Never apply 5 V to the 3.3 V input.
- 3.3 V is the recommended supply.

---

## 3. ESP32 I2C connection

ESP32 boards do not all use the same SDA and SCL pins.

You normally initialize I2C like this:

```cpp
Wire.begin(SDA_PIN, SCL_PIN);
```

Example for a common ESP32-WROOM setup:

```cpp
Wire.begin(21, 22);   // SDA = GPIO21, SCL = GPIO22
```

Example for some ESP32-S3 boards:

```cpp
Wire.begin(8, 9);     // SDA = GPIO8, SCL = GPIO9
```

These are examples only. Check the pinout for your exact ESP32 board.

### Typical ESP32-WROOM connection

| ESP32 | KW007 |
|---|---|
| GPIO21 | SDA |
| GPIO22 | SCL |
| GND | GND |
| 3.3V or 5V | Matching KW007 power input |

Also connect the KW007 **Range1** pin to GND through the required protection resistor.

> Important: SDA/SCL pin numbers vary between ESP32, ESP32-C3, ESP32-S3, and third-party development boards.

---

## 4. First test: BasicRead

Open:

**File > Examples > Keywave KW007 > BasicRead**

Before uploading, confirm that the example uses the correct SDA and SCL pins for your ESP32 board.

Example:

```cpp
Wire.begin(21, 22);
```

Upload the example, then open the **Serial Monitor** at `115200` baud.

### If the wiring is wrong

You may see:

```text
KW007_Init failed, status=0x20
```

This means the sensor did not acknowledge the I2C request.

Check:

- SDA wiring
- SCL wiring
- GND
- sensor power
- Range1 connection
- correct ESP32 SDA/SCL pin numbers

### If the connection is correct

You should see output similar to:

```text
KW007 Ready
Approaching=NO  Leaving=NO  RSSI=32
Approaching=NO  Leaving=NO  RSSI=132
```

Move toward the sensor and then move away from it to see the direction flags change.

---

## 5. MotionLED example

Open:

**File > Examples > Keywave KW007 > MotionLED**

ESP32 boards do not always provide the same onboard LED pin, so this example uses a user-defined LED GPIO.

Example:

```cpp
#define LED_PIN 2
```

Connect an external LED to the selected GPIO if your board does not have a suitable onboard LED.

Typical external LED connection:

```text
ESP32 GPIO -> resistor -> LED anode (+)
LED cathode (-) -> GND
```

Expected behavior:

- **Approaching** -> LED blinks twice
- **Leaving** -> LED blinks once

The same event is also shown in the Serial Monitor.

> GPIO 2 is only an example. Use a suitable GPIO for your specific ESP32 board.

---

## 6. Detecting motion without direction

If your application does not care whether the target is approaching or leaving:

```cpp
bool motion = data.approaching || data.leaving;
```

When either direction is detected, `motion` becomes `true`.

> This is a motion indication based on the approaching/leaving flags. It is not a dedicated stationary-presence or occupancy flag.

---

## 7. Basic example

```cpp
#include <Wire.h>
#include <KW007.h>

#define SDA_PIN 21
#define SCL_PIN 22

void setup()
{
    Serial.begin(115200);

    // Change SDA_PIN and SCL_PIN to match your ESP32 board.
    Wire.begin(SDA_PIN, SCL_PIN);

    uint8_t status = KW007_Init();

    if (status != KW007_OK)
    {
        Serial.print("KW007 init failed, status=0x");
        Serial.println(status, HEX);

        while (true)
        {
            delay(1000);
        }
    }

    // Range setting 4 is approximately 3 m.
    KW007_SetDetectionRange(4);

    Serial.println("KW007 Ready");
}

void loop()
{
    KW007_Data data = KW007_Read();

    if (data.ok)
    {
        Serial.print("Approaching=");
        Serial.print(data.approaching ? "YES" : "NO");

        Serial.print("  Leaving=");
        Serial.print(data.leaving ? "YES" : "NO");

        Serial.print("  RSSI=");
        Serial.println(data.rssi);
    }

    delay(128);
}
```

---

## 8. Detection range

Use:

```cpp
KW007_SetDetectionRange(range);
```

`range` can be from `1` to `8`.

| Setting | Approximate distance |
|---:|---:|
| `1` | ~20 cm |
| `2` | ~50 cm |
| `3` | ~1 m |
| `4` | ~3 m |
| `5` | ~5 m |
| `6` | ~7 m |
| `7` | ~10 m |
| `8` | ~12 m, enhanced mode |

Example:

```cpp
KW007_SetDetectionRange(4);
```

Range setting 4 is approximately 3 m under typical conditions.

Actual detection distance depends on target size, installation, obstruction, motion, power quality, and environment.

---

## 9. I2C address

KW007 uses the 7-bit I2C address:

```text
0x19
```

The library handles the address conversion internally. Application code normally does not need to handle the address directly.

---

## 10. Reading sensor data

Use:

```cpp
KW007_Data data = KW007_Read();
```

Available fields:

```cpp
data.ok
data.approaching
data.leaving
data.isDay
data.rssi
```

- `data.ok` — `true` when the I2C read was successful.
- `data.approaching` — `true` when approaching motion is detected.
- `data.leaving` — `true` when leaving motion is detected.
- `data.isDay` — reports the KW007 day/night flag.
- `data.rssi` — signal-strength value from `0` to `255`.

---

## 11. Common configuration commands

```cpp
KW007_Init();
KW007_Read();
KW007_SetDetectionRange(range);
KW007_SetThreshold(value);
KW007_SetGPO_DelayDuration(delay);
KW007_SetSamplingRate(use500Hz);
```

For most users, the recommended starting point is:

```cpp
Wire.begin(SDA_PIN, SCL_PIN);
KW007_Init();
KW007_SetDetectionRange(4);
```

Then read the sensor with:

```cpp
KW007_Data data = KW007_Read();
```

---

## 12. Troubleshooting

### `KW007_Init failed, status=0x20`

The sensor did not acknowledge the I2C request.

Check:

1. SDA and SCL are connected correctly.
2. The GPIO numbers in `Wire.begin(SDA_PIN, SCL_PIN)` are correct.
3. GND is shared between ESP32 and KW007.
4. KW007 is powered correctly.
5. Range1 is connected correctly before power-up.

### BasicRead works, but MotionLED does not

The KW007 communication may still be working correctly.

Check:

- the selected `LED_PIN`
- whether your ESP32 board has a normal onboard LED
- whether the onboard LED is active-high or active-low
- whether your board uses an RGB / NeoPixel LED instead of a simple GPIO LED

Using an external LED is the most reliable test.

### No approaching or leaving detection

Check:

1. `KW007_Init()` completed successfully.
2. The selected detection range is suitable.
3. The sensor is facing the target correctly.
4. The target is moving within the sensing area.

---

## 13. Library contents

```text
KW007_ESP32_v1.3.0/
|
|-- library.properties
|-- keywords.txt
|-- README.md
|-- CHANGELOG.md
|-- LICENSE
|
|-- src/
|   |-- KW007.h
|   |-- KW007_api.c
|   |-- KW007_api.h
|   |-- kw007_reg.c
|   |-- kw007_reg.h
|   |-- kw007_hal.h
|   `-- kw007_hal_arduino.cpp
|
`-- examples/
    |-- BasicRead/
    |   `-- BasicRead.ino
    |
    `-- MotionLED/
        `-- MotionLED.ino
```

The files inside `src/` are installed and compiled automatically by Arduino IDE.

You do not need to rename or manually copy these files.

---

## 14. Typical application flow

```cpp
#include <Wire.h>
#include <KW007.h>

Wire.begin(SDA_PIN, SCL_PIN);
KW007_Init();
KW007_SetDetectionRange(4);
KW007_Data data = KW007_Read();
```

You do not need direct register access for normal applications.

---

## 15. License

Copyright 2026 Keywave Technology.

First-party contents are licensed under the Apache License, Version 2.0.

See `LICENSE` for the complete license text.

# SDK v1.3 Detection Range and Sensitivity

`KW007_SetDetectionRange()` now applies gain, threshold, sensitivity and enhanced mode together.

| Range | Approx. distance | Amp1 | Amp2 | Amp3 | Threshold | Sensitivity | Enhanced |
|---:|---:|---:|---:|---:|---:|---:|:---:|
| 1 | ~20 cm | 4 | 0 | 0 | 80 | 2 | Off |
| 2 | ~50 cm | 6 | 0 | 0 | 80 | 2 | Off |
| 3 | ~1 m | 4 | 5 | 0 | 80 | 2 | Off |
| 4 | ~3 m | 7 | 4 | 0 | 80 | 4 | Off |
| 5 | ~5 m | 7 | 7 | 0 | 90 | 8 | Off |
| 6 | ~7 m | 7 | 7 | 1 | 64 | 8 | Off |
| 7 | ~10 m | 7 | 7 | 3 | 32 | 8 | Off |
| 8 | ~12 m | 7 | 7 | 3 | 32 | 8 | On |

Ranges 1-3 reproduce the sensor's hardware range-selection behaviour. Ranges 4-8 are software-control presets provided by the SDK.

Fine tuning is available with:

```cpp
KW007_SetSensitivity(4);
```

Sensitivity range:

```text
0  = most sensitive
15 = least sensitive
```

If custom sensitivity is required, call `KW007_SetSensitivity()` **after** `KW007_SetDetectionRange()`, because changing the range applies its own sensitivity preset.

# Range1 Requirement for I2C Control

For I2C / software-control mode, connect **Range1 directly to GND before power-up**.

Do not use a series resistor on Range1 in software-control mode. A resistor is used for hardware range selection; direct GND selects I2C control.

# Register Safety

`KW007_Init()` writes registers R00-R30 only.

Do not write R31.
