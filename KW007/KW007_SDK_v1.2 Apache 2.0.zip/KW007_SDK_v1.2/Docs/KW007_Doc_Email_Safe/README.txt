KW007 SDK v1.2 - Email-Safe Documentation
==========================================

Start here:
  Open index.html in a modern web browser.

Also included:
  KW007_Programming_Guide_v2.0c.pdf

This package contains a JavaScript-free version of the API reference so
it can be attached to Gmail. Navigation and the documentation pages work
locally without a web server or internet connection. Interactive search,
the expandable navigation tree, and code-copy buttons are not included.

Copyright 2026 Keywave Technology.
Licensed under the Apache License, Version 2.0 (Apache-2.0).
See LICENSE.txt and THIRD_PARTY_NOTICES.txt.
